#!/bin/python
import time
import sys
import getopt
arg1 = None
arg2 = None
argv = sys.argv[1:]
try:
    opts, args = getopt.getopt(argv, "H:P:")
except:
    print("Error")
for opt, arg in opts:
    counter = 1
    if opt in ['-H']:
        arg1 = arg
    elif opt in ['-P']:
        arg2 = arg
m=[]
n=[]
filePath=str(arg1)
file=open(filePath, 'r')
for i in file:
    if not i:
        pass
    else:
        m.append(i)
for j in m:
    n.append(j[:-1])
for k in n:
    pt = int(k.replace(' ', ''), 2)
    print(pt.to_bytes((pt.bit_length() + 7) // 8, 'big').decode())
