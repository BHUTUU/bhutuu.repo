#!/bin/python
import time
import sys
import getopt
arg1 = None
arg2 = None
argv = sys.argv[1:]
try:
    opts, args = getopt.getopt(argv, "H:P:")
except:
    print("Error")
for opt, arg in opts:
    counter = 1
    if opt in ['-H']:
        arg1 = arg
    elif opt in ['-P']:
        arg2 = arg
word=str(arg1)
print((bin(int.from_bytes(word.encode(), 'big')))[2:])
