module Net
  class Protocol; end
  class POP3 < Protocol
    VERSION = "0.1.0"
  end
end
